package Controller;

import java.util.*;

import javax.swing.ImageIcon;

import Characters.Character;
import Characters.Dragon;
import Characters.DragonAwake;
import Characters.Troll;
import Items.Bouclier;
import Items.Bourse;
import Items.Coeur;
import Items.Coin;
import Items.Cristaux;
import Items.Item;
import Model.Case;
import Model.Entity;
import Obstacles.Forest;
import Obstacles.Obstacle;
import Obstacles.Rock;
import Obstacles.Water;
import images.Images;
/**
 * This is the controller of the game.
 * @author brahim, prukev
 *
 */
public class Jeu {
	/**
	 * game icons images
	 */
	Images images=new Images();
	/**
	 * This list will contain all the entities there will be in the game
	 */
    private HashSet<Entity> listeEntity = new HashSet<Entity>();
    
    /**
     * This list will be use for the dragon fire function
     */
    private HashSet<Entity> tabRemoveEntity= new HashSet<Entity>();
    
    /**
     * This list will contains all the dragons
     */
    private HashSet<Dragon> dragonList = new HashSet<Dragon>();
    
    /**
     * This list will contain all the trolls
     */
    private List <Troll> trollList = new ArrayList<Troll>();
    
    /**
     * This table will represent the board/map of the game
     */
    private Case[][] plateau;
    
    /**
     * This case will be important because it will represent the start case of the trolls
     */
    private Case start;
    
    /**
     * This will contains the score max possible
     */
    public int scoreMax = 0;
    
    /**
     * In order to play, the player must select a character. The game's actions are used in this variable
     * which is the selected character
     */  
	private Character actualCharacter = null;
    
    /**
     * Since this class is a singleton, this variable represents the instance
     */
	private static Jeu instance = null;
	
	/**
	 * This number will represent the size of the table
	 */
    private static int nbLimite = 0;
    
    /**
     * This number will represent the actual of players.
     */
    private int actifPlayer = 0;
    
    /**
     * This number will represent the number of players.
     */
    private static int maxPlayer = 2;
    
    /**
     * This list will contains all the losing players
     */
    private List<Troll> deletedPlayers;
    
    /**
     * This number will represent the number of dragons
     */
    private static int maxDragon = 1;
    
    /**
     * This boolean will stop the game if it's true
     */
    protected boolean over = false;
    
    /**
     * This variable will display the actual turn
     */
    private int nbTurns = 1;
    
    /**
     * This boolean will be useful when a player wants to play the game with a dice.
     */
    private static boolean diceMode = false;
    
    
	
	
	/**
	 * This table will contain all the icons of the trolls
	 */
	private ImageIcon[] trollIcon = { images.getTroll1Icon(), images.getTroll2Icon(), images.getTroll3Icon(), images.getTroll4Icon(),
			images.getTroll1ShieldIcon(),images.getTroll2ShieldIcon() ,images.getTroll3ShieldIcon() ,images.getTroll4ShieldIcon() };  
    
    /**
     * This is the constructor. Since it's a singleton, it must be private.
     * @param nbCase
     */
	private Jeu(int nbCase) {
		this.plateau = new Case[nbCase][nbCase];//The table will be a table of table size of the argument
		for (int i = 0; i < nbCase; ++i) {
			for (int j = 0; j < nbCase; ++j) {
				this.plateau[i][j] = new Case(i,j);//We create each Case in the table
			}
		}
		Jeu.nbLimite = nbCase;//We register the number max of the table
		if (maxPlayer > 3||Jeu.nbLimite >9) {
			for(int i=0;i<8;i++){
				addRandomItem();
			}
		}
		this.deletedPlayers = new ArrayList<Troll>(4);
	}
	
	/**
	 * This method returns the instance of the object
	 * @param nbCase
	 * @return instance
	 */
	public static synchronized Jeu getInstance(int nbCase) {
		if(nbCase<9){
			nbCase=9;
		}
		if(nbCase>11){
			nbCase=11;
		}
		if (instance == null) instance = new Jeu(nbCase);
		return instance;
	}
	
	/**
	 * Use later for a reset option
	 */
	public static synchronized void newInstance() {
		instance = null;
	}
	
	/**
	 * This method execute the move of the selected character
	 * @param newC
	 */
	public void	deplacer(Case newC) {
		
		//We execute the test of the collision function of the character
		if (!actualCharacter.detecteCollision(newC) && !over) {
			actualCharacter.deplacer(newC);//If we can, we move
		}
		//If the selected character is a troll, we execute the addItem operation
		
		if (actualCharacter instanceof Troll){
			Troll t=(Troll)actualCharacter;
			(t).addItem();
			if(!t.getIncomes().isEmpty()&&(t.getPosition()).equals(t.getDepart())){
				((Troll)actualCharacter).incomesEffet();
			}
		}
	}
	
	/**
	 * Actual Character getter
	 * @return  actualCharacter
	 */
	public Character getCharacter() {
		return this.actualCharacter;
	}
	
	/**
	 * Actual character setter. Used for the selection
	 * @param e
	 */
	public void setCharacter(Character e) {
		this.actualCharacter = e;
	}
	
	/**
	 * Game table getter
	 * @return plateau
	 */
	public Case[][] getPlateau() {
		return this.plateau;
	}
	
	/**
	 * This operation add an entity to the game
	 * @param e
	 * @param x
	 * @param y
	 */
	public void addEntity(Entity e, int x, int y) {
		this.plateau[x][y].addEntity(e);
		this.listeEntity.add(e);
		e.setPosition(this.plateau[x][y]);
		if (e instanceof Troll) {
			((Troll) e).setDepart(this.plateau[x][y]);
			this.start = this.plateau[x][y];
			this.trollList.add((Troll)e);
		}
		if (e instanceof Dragon) this.dragonList.add((Dragon)e);
		if (e instanceof Coin || e instanceof Bourse) this.scoreMax += ((Item)e).getBonus();
	}

	/**
	 * listeEntity getter
	 * @return listeEntity
	 */
	public HashSet<Entity> getListeEntity() {
		return listeEntity;
	}

	/**
	 * Setter of the listEntity
	 * @param listeEntity
	 */
	public void setListeEntity(HashSet<Entity> listeEntity) {
		this.listeEntity = listeEntity;
	}

	/**
	 * This function represents the fire function of the dragon executed at each end turn
	 * @param limite
	 */
	public void dragonFire(int limite) {
		//We execute the operation only if the dragon was the selected character
		if (this.actualCharacter instanceof Dragon) {
			
			Dragon drag = (Dragon) this.actualCharacter;
			if (drag.getEtat() instanceof DragonAwake) {
				//We get all the Cases around the dragon
				ArrayList<Case[]> zone = ((Dragon) this.actualCharacter).getZoneFeu(limite,this);
				
				//We execute successifs checking on each case
				for (Case[] lacase : zone) {
					
						for (int i = 0; i < 3; ++i) {
							
							/*
							 * We look if there is a rock in the order of verification. If there is, 
							 * we stop the analysis.
							 */
							if (lacase[i] != null && !lacase[i].getEntity().isEmpty() &&
									(lacase[i].getFirstEntity() instanceof Rock)) {	
								break;//F
							}
							
							//If there is an entity and we can apply the dragon's effect, we do it
							if (lacase[i] != null && lacase[i].getEntity() != null) {
	
									for (Entity entite : lacase[i].getEntity()) {
										//But we first save it in an intermediary list
										tabRemoveEntity.add(entite);	
									}
					
							}	
						}
					
				}
				
				//This part represents the application of the dragon's fire on the dragon's position
				for (Entity entite : this.actualCharacter.getPosition().getEntity()) {
					tabRemoveEntity.add(entite);
				}
				
				//Since we can't delete something from a list on reading mode, we delete it from an other list
				for (Entity entite : tabRemoveEntity) {
					
					//Her we search if tabRemoveEntity contains a troll
					if(entite instanceof Troll){
						Troll t=(Troll)entite;
						
						//Her we make sure that this troll don't has shield
						if(t.getBouclier() == 0){
							returnIncomes(t);
						}
					}
					entite.dragonEffet();
				}
				tabRemoveEntity = new HashSet<Entity>();
			}
		}
	}
	
	/**
	 * This function adds new item when there is a lot of players.
	 */
	public void addRandomItem() {
		Item i = null;
		int c= (int) (Math.random() *nbLimite-1);
		int l= (int) (Math.random() *nbLimite-1 );
		if(plateau[l][c].getEntity().isEmpty()){
			if (l == nbLimite%2) {
				i = new Bourse(images.getBourseIcon());
				i.setPosition(new Case(l,c));
				this.scoreMax+=i.getBonus();
			} else {
				i = new Coin(images.getCoinIcon());
				i.setPosition(new Case(l,c));
				this.scoreMax+=i.getBonus();
			}
			plateau[l][c].addEntity(i);
	}
	  
	  
  }
  
  /**
   * Take an id as a parameter in order to return a troll
   * @param troll
   * @return e or null
   */
  public Troll searshTrollById(String troll){
	  for(Entity e :listeEntity){
		  if((e instanceof Troll ) && e.getId().equals(troll)){
			  return (Troll)e;
		  }
	  } 
	  return null;
  }
  
  /**
   * Same as the previous one but we search a dragon
   * @param dragon
   * @return e or null
   */
  public Dragon searshDragonById(String dragon){
	  for(Entity e :listeEntity){
		  if((e instanceof Dragon ) && e.getId().equals(dragon)){
			  return (Dragon)e;
		  }
	  } 
	  return null;
  }
  
	/**
	 * This function fill the game of a lot of entities
	 */
	@SuppressWarnings("static-access")
  	public void fillTable() {
		Dragon d;
		for (int i = 0; i < this.maxDragon; ++i) {
			d = new Dragon(images.getDragonSleepingIcon(), images.getDragonIcon());
			//This equation allows to put one drogon near coins and the other one near the shields
			this.addEntity(d, i*7, 7-6*i);
			
		}
		
		Troll t;
		for (int i = 0; i < this.maxPlayer; ++i) {
			t = new Troll(this.trollIcon[i], this.trollIcon[4+i]);
			t.setJoueur(i);
			this.addEntity(t, 4, 4);
			if (i ==0) actualCharacter = t;
			if (diceMode) t.setDeplacementMax(0);
		}
		
		Rock r1 = new Rock(images.getRockIcon());
		Rock r2 = new Rock(images.getRockIcon());
		Rock r3 = new Rock(images.getRockIcon());
		Rock r4 = new Rock(images.getRockIcon());
		Rock r5 = new Rock(images.getRockIcon());
		Rock r6 = new Rock(images.getRockIcon());
		Water w1 = new Water(images.getWaterIcon());
		Water w2 = new Water(images.getWaterIcon());
		Forest f1 = new Forest(images.getForestIcon());
		Forest f2 = new Forest(images.getForestIcon());
		Forest f3 = new Forest(images.getForestIcon());
		Forest f4 = new Forest(images.getForestIcon());
		Forest f5 = new Forest(images.getForestIcon());
		Forest f6 = new Forest(images.getForestIcon());
		Coin c1 = new Coin(images.getCoinIcon());
		Coin c2 = new Coin(images.getCoinIcon());
		Coin c3 = new Coin(images.getCoinIcon());
		Coin c4 = new Coin(images.getCoinIcon());
		Coin c5 = new Coin(images.getCoinIcon());
		Coin c6 = new Coin(images.getCoinIcon());
		Bourse b1 = new Bourse(images.getBourseIcon());
		Bourse b2 = new Bourse(images.getBourseIcon());
		Cristaux cr1 = new Cristaux(images.getCristalIcon());
		Cristaux cr2 = new Cristaux(images.getCristalIcon());
		Coeur co1 = new Coeur(images.getHeartIcon());
		Coeur co2 = new Coeur(images.getHeartIcon());
		Coeur co3 = new Coeur(images.getHeartIcon());
		Bouclier bo1 = new Bouclier(images.getShieldIcon());
		Bouclier bo2 = new Bouclier(images.getShieldIcon());
		Bouclier bo3 = new Bouclier(images.getShieldIcon());
		this.addEntity(cr1, 4,0);
		this.addEntity(cr2, 7,7);
		this.addEntity(co1, 6,7);
		this.addEntity(co2, 5,0);
		this.addEntity(co3, 1,8);
		this.addEntity(bo1, 7,0);
		this.addEntity(bo2, 7,5);
		this.addEntity(bo3, 6,0);
		this.addEntity(c1, 0,3);
		this.addEntity(c2, 0,5);
		this.addEntity(c3, 2,3);
		this.addEntity(c4, 2,4);
		this.addEntity(c5, 2,6);
		this.addEntity(c6, 3,6);
		this.addEntity(b1, 0,6);
		this.addEntity(b2, 2,5);
		this.addEntity(r1, 1, 1);
		this.addEntity(r2, 1, 2);
		this.addEntity(r3, 2, 2);
		this.addEntity(r4, 1, 4);
		this.addEntity(r5, 5, 6);
		this.addEntity(r6, 6, 6);
		this.addEntity(w1, 3, 5);
		this.addEntity(w2, 4, 5);
		this.addEntity(f1, 1, 5);
		this.addEntity(f2, 3, 4);
		this.addEntity(f3, 4, 1);
		this.addEntity(f4, 5, 1);
		this.addEntity(f5, 5, 3);
		this.addEntity(f6, 6, 1);
	}

	/**
	 * Getter of maxplayers
	 * @return maxPlayer
	 */
	public static int getMaxPlayer() {
		return maxPlayer;
	}

	/**
	 * Setter of maxplayer. Used for the customization in the options menu
	 * @param player
	 */
	public static void setMaxPlayer(int player) {
		if (player < 2) player = 2;
		if (player >4)player = 4; 
		maxPlayer = player;
	}

	/**
	 * actifPlayer getter
	 * @return actifPlayer
	 */
	public int getActifPlayer() {
		return actifPlayer;
	}

	/**
	 * maxDragon getter
	 * @return maxDragon
	 */
	public int getMaxDragon() {
		return maxDragon;
	}

	/**
	 * maxDragon Setter. Used in the options menu
	 * @param dragon
	 */
	public static void setMaxDragon(int dragon) {
		if(dragon<=1){
			dragon=1;
		}
		if(dragon>2){
			dragon=2;
		}
		maxDragon = dragon;
	}

	public int getScoreMax() {
		return scoreMax;
	}

	public void setScoreMax(int scoreMax) {
		this.scoreMax = scoreMax;
	}

	/**
	 * This function will be used when a turn ends. It's also where the game's loop is
	 */
	public void endTurn() {
		if (this.actualCharacter != null) {
			this.actualCharacter.resetDeplacement();//Move reset if the selected character is not null
			
			if (diceMode) {
				for (Entity e : listeEntity) {
					if (e instanceof Character) {
						((Character)e).setDeplacementMax(0);
					}
				}
			}
			
			if (this.actualCharacter instanceof Troll) {
				Troll t = (Troll)this.actualCharacter;
				if (maxPlayer != 0 && t.getScore() >= this.scoreMax/maxPlayer) this.over = true;
			}
			
			//If a dragon stops its movement on an obstacle
			if (this.actualCharacter.getPosition().getEntity().size() > 1) {
				for (Entity entite : this.actualCharacter.getPosition().getEntity()) {
					if (entite instanceof Obstacle) {
						this.actualCharacter.turnBack();//We move the dragon to its previous position
					}
				}
			}
		}
		
		//Time to check if all the awaken dragons go back to sleep
		for (Dragon d : dragonList) {
			if (d.getEtat() instanceof DragonAwake) {
				DragonAwake dA = (DragonAwake)d.getEtat();
				if ((this.nbTurns - dA.getNbTurn()) >= 5) d.sleep();
			}
		}

		this.dragonFire(nbLimite);//Execution of the dragon fire operation
		
		for (Troll t : this.trollList) {
			if (t.getNbLifes() == 0) {
				this.listeEntity.remove(t);
				this.tabRemoveEntity.add(t);
				this.deletedPlayers.add(t);
			}
		}
		
		for (Entity e : this.tabRemoveEntity) {
			e.getPosition().deleteEntity(e);
			this.trollList.remove(e);
		}
		
		this.tabRemoveEntity = new HashSet<Entity>();
		
		if ((this.trollList).size() <= 1) this.over = true;
		
		setCharacter(null);//Reset of the selected character
		
		if (this.actifPlayer == maxPlayer-1) nbTurns++;
		
		if (!isOver()) this.actifPlayer++;
		while (containPlayer(this.actifPlayer)) {
			this.actifPlayer++;
		}
		
		if (maxPlayer != 0) this.actifPlayer = this.actifPlayer % maxPlayer;//Change of player
		
		this.actifPlayer = this.actifPlayer % maxPlayer;//Change of player
		
		//The selected character is the next troll
		actualCharacter = searshTrollById("Troll_" + (actifPlayer + 1));
	}
	
	/**
	 * This function is used to pass the turn of a dead player
	 * @param player
	 * @return true/false
	 */
	public boolean containPlayer(int player) {
		for (Troll t : this.deletedPlayers) {
			if (t.getJoueur() == player) return true;
		}
		return false;
	}

	/**
	 * NbTurn getter
	 * @return nbTurns
	 */
	public int getNbTurns() {
		return nbTurns;
	}
   
	/**
	 * Getter of over. True if the game is over
	 * @return over
	 */
	public boolean isOver() {
		return over;
	}
	
	/**
	 * This function will allow all the dragons to wake up
	 */
	public void wakeUpDragons(){
		for (Dragon d : dragonList) {
			d.wakeUp();
			((DragonAwake)d.getEtat()).setNbTurn(this.nbTurns);
		}
	}

	/**
	 * Setter of nbLimit 
	 * @param i
	 */
	public static void setNbLimite(int i) {
		nbLimite=i;
	}

	/**
	 * nbLimit getter
	 * @return nbLimite
	 */
	public static int getNbLimite() {
		return nbLimite;
	}

	/**
	 * Getter of the start position of all trolls
	 * @return start
	 */
	public Case getStart() {
		return start;
	}

	/**
	 * Setter of the start position
	 * @param start
	 */
	public void setStart(Case start) {
		this.start = start;
	}

	/**
	 * DiceMode getter. If it's true, the game works with a dice. Otherwise it's normal
	 * @return diceMode
	 */
	public boolean onDiceMode() {
		return diceMode;
	}
	
	/**
	 * Option dice setter. It's by this function we make the dice mode or not
	 * @param b
	 */
	public static void setOptionDice(boolean b) {
		diceMode = b;
	}
	
	/**
	 * This function will return the troll's incomes into the gamePlateau 
	 * @param troll
	 */
	void returnIncomes(Troll troll){
		//Item it position
    	Case c; 
    	int itAbscisse,itOrdonne;
	    for(Item it :troll.getIncomes()){
    		c = it.getPosition();
			itAbscisse = c.getAbscisse();
			itOrdonne = c.getOrdonne();
			//we add it as first Entity of it square
		    plateau[itAbscisse][itOrdonne].getEntity().add(0, it);
    	 }
    	troll.setIncomes(new ArrayList<Item>());
	  }

	public Images getImages() {
		return images;
	}

	public void setImages(Images images) {
		this.images = images;
	}
	  
}
