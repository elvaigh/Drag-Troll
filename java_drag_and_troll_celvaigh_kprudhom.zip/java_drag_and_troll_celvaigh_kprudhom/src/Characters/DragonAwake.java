/**
 * 
 */
package Characters;

import Model.Case;

/**
 * This is the awaken state of the dragon
 * @author brahim, prukev
 */
public class DragonAwake implements EtatDragon {
	
	/**
	 * This number will take the actual turn of game when the dragon wakes up
	 */
	private int nbTurn = 0;
	
	/**
	 * No modifications in the constructor
	 */
	public DragonAwake() {
	}
	
	
	/**
	 * This function will be called only if the dragon is awake
	 */
	public void deplacer(Case newCase, Dragon dragon){
			if (dragon.deplacementActuel < dragon.deplacementMax) {
				dragon.previousPosition = dragon.getPosition();
				dragon.getPosition().deleteEntity(dragon);
				newCase.addEntity(dragon);
				dragon.setPosition(newCase);
				dragon.deplacementActuel++;
			}
	}

	/**
	 * Nbturn getter
	 * @return nbTurn
	 */
	public int getNbTurn() {
		return nbTurn;
	}

	/**
	 * NbTurn setter
	 * @param nbTurn
	 */
	public void setNbTurn(int nbTurn) {
		this.nbTurn = nbTurn;
	}
	
	

}
