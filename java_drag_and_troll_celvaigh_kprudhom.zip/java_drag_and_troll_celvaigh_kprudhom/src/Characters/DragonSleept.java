package Characters;

import Model.Case;

/**
 * This is the sleeping state of the dragon
 * @author brahim, prukev
 */
public class DragonSleept implements EtatDragon {
	
	/**
	 * Nothing in the constructor
	 */
	public DragonSleept() {
	}
	
	/**
	 * 
	 * No effect if the dragon is sleeping
	 */
	public void deplacer(Case newCase, Dragon dragon){
		
	}

}
