
package Obstacles;

import Model.Entity;

/**
 * This class represents the base of all obstacles which will follow this base 
 * @author prukev, Brahim
 *
 */
public abstract class Obstacle extends Entity {

	/**
	 * Every obstacle has a difficulty which will be important depending the game environment
	 */
	protected int difficulty;

	/**
	 * ToString function
	 */
	@Override
	public String toString() {
		return "Obstacle [difficulty=" + difficulty + "]";
	}
	
	
	
}
