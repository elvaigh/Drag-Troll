package Obstacles;

import javax.swing.ImageIcon;

/**
 * This class represents the forest object which will be a simple obstacle
 * @author prukev, Brahim
 *
 */
public class Forest extends Obstacle {

	/**
	 * This data can give us the number of Forest there is in the game. It's also use for the id.
	 */
	private static int nbForest = 1;
	
	/**
	 * This is the forest's constructor. It has an image and a difficulty
	 * @param img
	 */
	@SuppressWarnings("static-access")
	public Forest(ImageIcon img) {
		this.myPicture = img;
		this.difficulty = 1;
		this.id = "Forest_" + this.nbForest;
		this.nbForest++;
	}

	/**
	 * When the dragon's fire touches a forest, it will be deleted.
	 */
	@Override
	public void dragonEffet() {
		this.myPicture = null;
		this.position.deleteEntity(this);
	}

	/**
	 * ToString function.
	 */
	@Override
	public String toString() {
		return "Forest []";
	}
	
	
	
}
