package Obstacles;

import javax.swing.ImageIcon;

/**
 * This class represents the rock object which will be the strongest obstacle
 * @author prukev, Brahim
 *
 */
public class Rock extends Obstacle {

	/**
	 * This data can give us the number of Rock there is in the game. It's also use for the id.
	 */
	private static int nbRock = 1;
	
	/**
	 * This is the rock's constructor. It has an image and a difficulty
	 * @param img
	 */
	@SuppressWarnings("static-access")
	public Rock(ImageIcon img) {
		this.myPicture = img;
		this.difficulty = 3;
		this.id = "Rock_" + this.nbRock;
		this.nbRock++;
	}

	@Override
	public String toString() {
		return "Rock []";
	}
	
	
}
