package Obstacles;

import javax.swing.ImageIcon;

/**
 * This class represents the water object which will be a little stronger than a forest
 * @author prukev, Brahim
 *
 */
public class Water extends Obstacle {

	/**
	 * This data can give us the number of Water there is in the game. It's also use for the id.
	 */
	private static int nbWater = 1;
	
	/**
	 * This is the water's constructor. It has an image and a difficulty
	 * @param img
	 */
	@SuppressWarnings("static-access")
	public Water(ImageIcon img) {
		this.myPicture = img;
		this.difficulty = 2;
		this.id = "Water_" + this.nbWater;
		this.nbWater++;
	}

	/**
	 * ToString function
	 */
	@Override
	public String toString() {
		return "Water []";
	}
	
	
	
}
