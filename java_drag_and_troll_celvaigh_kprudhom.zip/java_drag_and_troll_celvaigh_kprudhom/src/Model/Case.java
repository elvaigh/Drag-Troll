package Model;

import java.util.ArrayList;

import Characters.Dragon;

/**
 * This class represent a kind of position for the entity. It's on this the players
 * can play on the plateau game.
 * @author prukev, Brahim
 *
 */
public class Case {

	/**
	 * This data represents the line in the table
	 */
	private int abscisse;
	
	/**
	 * This data represent the column in the table
	 */
	private int ordonnee;
	
	/**
	 * For each case, there is a possibility to have one or more entities
	 */
	private ArrayList<Entity> entity; 
	
	/**
	 * This is the case constructor. It takes a position as an argument
	 * @param x
	 * @param y
	 */
	public Case(int x, int y) {
		this.abscisse = x;
		this.ordonnee = y;
		this.entity = new ArrayList<Entity>();
	}
	
	/**
	 * This is the getter of the list
	 * @return this.entity
	 */
	public ArrayList<Entity> getEntity() {
		return this.entity;
	}

	/**
	 * This function returns the first entity of the list
	 * @return this.entity.get(0)
	 */
	public Entity getFirstEntity() {
		return this.entity.get(0);
	}
	
	/**
	 * This function add the entity in argument to the list
	 * @param e
	 */
	public void addEntity(Entity e) {
		this.entity.add(e);
	}
	
	/**
	 * This function remove the entity in argument from the list
	 * @param e
	 */
	public void deleteEntity(Entity e) {
		Entity et=null;
		if (getFirstEntity() == e && !getFirstEntity().equals(e) && !(getFirstEntity() instanceof Dragon)) {
				Entity tempEntity = this.entity.get(0);
				this.entity.add(tempEntity);
				this.entity.remove(0);
				this.entity.remove(e);
		} else {
			for(Entity entite : this.entity){
				if(entite.equals(e)){
					 et=entite;
				}
			}
				this.entity.remove(et);
		}
		
	}
	
	/**
	 * Getter of the line
	 * @return this.abscisse
	 */
	public int getAbscisse() {
		return this.abscisse;
	}
	
	/**
	 * Getter of the column
	 * @return this.ordonnee
	 */
	public int getOrdonne() {
		return this.ordonnee;
	}


	/** 
	 * Equals function
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Case)) {
			return false;
		}
		Case other = (Case) obj;
		if (abscisse != other.abscisse) {
			return false;
		}
		if (entity == null) {
			if (other.entity != null) {
				return false;
			}
		} else if (!entity.equals(other.entity)) {
			return false;
		}
		if (ordonnee != other.ordonnee) {
			return false;
		}
		return true;
	}

	/**
	 * ToString function
	 */
	@Override
	public String toString() {
		return "Case [abcisse=" + abscisse + ", ordonnee=" + ordonnee + "]";
	}
	
}
