package Items;

import javax.swing.ImageIcon;

/**
 * This class represent the cristal object
 * @author prukev, Brahim
 *
 */
public class Cristaux extends Item {

	/**
	 * This data can give us the number of Cristal there is in the game. It's also use for the id.
	 */
	private static int nbCristaux = 1;
	
	/**
	 * This is the Cristal's constructor. It takes an Image in argument. In the minimal version of
	 * the game, the image is null
	 * @param img
	 */
	@SuppressWarnings("static-access")
	public Cristaux(ImageIcon img) {
		this.myPicture = img;
		this.setBonus(1);
		this.id = "Cristaux_" + this.nbCristaux;
		this.nbCristaux++;
		
	}

}
